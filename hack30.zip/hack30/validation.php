<?php

session_start();
$con = mysqli_connect('localhost','root');
if($con)
{
    echo "Sign Up Successfully";
}
else{
    echo "no connection";
}

mysqli_select_db($con, 'signup');

$user_email = $_POST['user_email'];
$user_password = $_POST['user_password'];


$q = "SELECT * from signupdata where user_email = '$user_email' && user_password='$user_password' ";
$result = mysqli_query($con, $q);
$num = mysqli_num_rows($result);

$q1 = "SELECT * from signupdata ORDER BY disease DESC ";
$result1 = mysqli_query($con, $q1);
$num1 = mysqli_num_rows($result1);

$q2= "SELECT * FROM signupdata ORDER BY disease DESC";
$result2 = mysqli_query($con, $q2);

if($num ==1){

	while($row = $result->fetch_assoc()) 
	  { 
	    $user_name = $row['user_name'];
	  }
      while($row2= $result1->fetch_assoc())
      { 
          $sco= $row2['disease'];
          break;
      }
      $count=1;
      while($row3= $result2 -> fetch_assoc())
      {
          
          if($row3['disease']==$sco && $row3['user_name']==$user_name)
          {   

              break;
          }
          else{
              $count++;
          }
      }

    $_SESSION['user_name'] = $user_name;
    $_SESSION['disease'] = $sco;
    $_SESSION['ivac']= $count;
    header('location:home.php');


}
else{
    header('location:login.php');
}


?>