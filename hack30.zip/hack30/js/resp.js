burger= document.querySelector('.burger')
navbar= document.querySelector('.navbar')
navlist= document.querySelector('.nav-list')


burger.addEventListener('click', ()=>{
    nav-list.classList.toggle('vclass');
    navbar.classList.toggle('hnav');
})